<?php
return array (
  'app_version' => 'v4.6.6',
  'full_app_version' => 'v4.6.6 - build 3926-g1a10aa0dd',
  'build_version' => '3926',
  'prerelease_version' => '',
  'hash_version' => 'g1a10aa0dd',
  'full_hash' => 'v4.6.6-24-g1a10aa0dd',
  'branch' => 'master',
);
